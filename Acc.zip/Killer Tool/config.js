module.exports = {
    numberOfRegisterInOneTime: 6, // no of registration want to make in one command.
    domains: ["lamoshitt.com", "crazzybabe.com"], // names of domain for the emails. 
    oneTimeMailGen: 10 * 100000,
    telegramBotToken: "7956584995:AAGbKOWbutFKfOygZwoMSXjX2NLc8gFOCWk", // bot token of telegram bot. Create a bot using https://t.me/BotFather then generate the token of the bot.
    adminNamesForTelegramBot: ["Roxz_gaming"], // name of the admin/developer who's name will be displayed when any unknown user use the command of the bot in telegram.
    authorisedUserForTelegramBot: ["aarav_0008","Roxz_gaming"] // username or id of the user who can use the bot.
};